<?php
session_start();
include 'db.php';
require_once 'csrf.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = (int) $_SESSION['user_id'];
$user_name = $_SESSION['name'] ?? 'User';

/* ── FILTERS ── */
$search    = trim($_GET['search']    ?? '');
$type      = trim($_GET['type']      ?? '');
$category  = trim($_GET['category']  ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to   = trim($_GET['date_to']   ?? '');
$sort      = in_array($_GET['sort'] ?? '', ['asc','desc']) ? $_GET['sort'] : 'desc';
$page_num  = max(1, (int)($_GET['page'] ?? 1));
$per_page  = 15;
$offset    = ($page_num - 1) * $per_page;

/* ── BUILD WHERE CLAUSE ── */
$where  = "WHERE user_id=? AND is_deleted_by_user=0";
$params = [$user_id];
$types  = 'i';

if ($search !== '') {
    $where .= " AND (category LIKE ? OR description LIKE ?)";
    $like = '%' . $conn->real_escape_string($search) . '%';
    $params[] = $like; $params[] = $like;
    $types .= 'ss';
}
if ($type !== '') {
    $where .= " AND type=?";
    $params[] = $type; $types .= 's';
}
if ($category !== '') {
    $where .= " AND category=?";
    $params[] = $category; $types .= 's';
}
if ($date_from !== '') {
    $where .= " AND COALESCE(NULLIF(date,'0000-00-00'), DATE(created_at)) >= ?";
    $params[] = $date_from; $types .= 's';
}
if ($date_to !== '') {
    $where .= " AND COALESCE(NULLIF(date,'0000-00-00'), DATE(created_at)) <= ?";
    $params[] = $date_to; $types .= 's';
}

/* ── TOTAL COUNT ── */
$count_stmt = $conn->prepare("SELECT COUNT(*) FROM transactions $where");
$count_stmt->bind_param($types, ...$params);
$count_stmt->execute();
$total_rows  = $count_stmt->get_result()->fetch_row()[0];
$total_pages = max(1, ceil($total_rows / $per_page));
$count_stmt->close();

/* ── FETCH TRANSACTIONS ── */
$order = "ORDER BY created_at $sort, transaction_id $sort";
$stmt  = $conn->prepare("SELECT * FROM transactions $where $order LIMIT ? OFFSET ?");
$params[] = $per_page; $params[] = $offset;
$types .= 'ii';
$stmt->bind_param($types, ...$params);
$stmt->execute();
$transactions = $stmt->get_result();
$stmt->close();

/* ── GLOBAL STATS (all records, no filter) ── */
$stats = $conn->query("
    SELECT
        SUM(CASE WHEN type='income'  THEN amount ELSE 0 END) AS total_income,
        SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) AS total_expense,
        COUNT(*)                                             AS total_count,
        SUM(CASE WHEN type='income'  THEN 1 ELSE 0 END)     AS income_count,
        SUM(CASE WHEN type='expense' THEN 1 ELSE 0 END)     AS expense_count
    FROM transactions
    WHERE user_id=$user_id AND is_deleted_by_user=0
")->fetch_assoc();

$total_income  = (float)($stats['total_income']  ?? 0);
$total_expense = (float)($stats['total_expense'] ?? 0);
$net           = $total_income - $total_expense;
$income_count  = (int)($stats['income_count']  ?? 0);
$expense_count = (int)($stats['expense_count'] ?? 0);
$total_count   = (int)($stats['total_count']   ?? 0);

/* ── FILTERED STATS (for summary reconciliation) ── */
$has_filter = $search || $type || $category || $date_from || $date_to;
$filtered_income  = 0; $filtered_expense = 0;
$filtered_income_count = 0; $filtered_expense_count = 0;
if ($has_filter) {
    $ftypes  = substr($types, 0, -2); // strip LIMIT/OFFSET param types
    $fparams = array_slice($params, 0, -2);
    $fs = $conn->prepare("SELECT
        SUM(CASE WHEN type='income'  THEN amount ELSE 0 END) AS fi,
        SUM(CASE WHEN type='expense' THEN amount ELSE 0 END) AS fe,
        SUM(CASE WHEN type='income'  THEN 1 ELSE 0 END)     AS fic,
        SUM(CASE WHEN type='expense' THEN 1 ELSE 0 END)     AS fec
        FROM transactions $where");
    $fs->bind_param($ftypes, ...$fparams);
    $fs->execute();
    $fr = $fs->get_result()->fetch_assoc();
    $filtered_income        = (float)($fr['fi']  ?? 0);
    $filtered_expense       = (float)($fr['fe']  ?? 0);
    $filtered_income_count  = (int)($fr['fic'] ?? 0);
    $filtered_expense_count = (int)($fr['fec'] ?? 0);
    $fs->close();
}

/* ── 7-DAY SPARKLINE DATA ── */
$spark = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $r = $conn->query("SELECT
        COALESCE(SUM(CASE WHEN type='income'  THEN amount ELSE 0 END),0) AS inc,
        COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END),0) AS exp
        FROM transactions
        WHERE user_id=$user_id AND is_deleted_by_user=0
          AND COALESCE(NULLIF(date,'0000-00-00'),DATE(created_at))='$d'")->fetch_assoc();
    $spark[] = ['date'=>date('D', strtotime($d)), 'net'=>(float)$r['inc'] - (float)$r['exp'], 'inc'=>(float)$r['inc'], 'exp'=>(float)$r['exp']];
}

/* ── CATEGORY BREAKDOWN (for mini donut) ── */
$cat_data = [];
$cr = $conn->query("SELECT category, SUM(amount) AS total FROM transactions
    WHERE user_id=$user_id AND is_deleted_by_user=0 AND type='expense'
    GROUP BY category ORDER BY total DESC LIMIT 6");
while ($row = $cr->fetch_assoc()) $cat_data[] = $row;

/* ── CATEGORIES for filter dropdown ── */
$cats = $conn->query("SELECT DISTINCT category FROM transactions WHERE user_id=$user_id AND is_deleted_by_user=0 ORDER BY category");

/* ── HIDDEN TRANSACTIONS (pagination note) ── */
$hidden_count = max(0, $total_rows - ($page_num * $per_page));

/* ── EXPORT CSV ── */
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="transactions_'.date('Y-m-d').'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','Type','Category','Amount (KES)','Date','Description']);
    $etypes  = substr($types, 0, -2);
    $eparams = array_slice($params, 0, -2);
    $es = $conn->prepare("SELECT * FROM transactions $where ORDER BY created_at DESC");
    $es->bind_param($etypes, ...$eparams);
    $es->execute();
    $er = $es->get_result();
    while ($row = $er->fetch_assoc()) {
        $dd = ($row['date'] === '0000-00-00' || empty($row['date'])) ? date('Y-m-d', strtotime($row['created_at'])) : $row['date'];
        fputcsv($out, [$row['transaction_id'], $row['type'], $row['category'], $row['amount'], $dd, $row['description']]);
    }
    fclose($out); exit;
}

/* ── HELPERS ── */
function display_date($row) {
    $d = $row['date'] ?? '';
    return (empty($d) || $d === '0000-00-00') ? date('d M Y', strtotime($row['created_at'])) : date('d M Y', strtotime($d));
}
function qs($extra=[]) {
    $p = array_merge($_GET, $extra);
    unset($p['export']);
    return '?' . http_build_query($p);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transactions — Finance</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
:root{
    --ink:#0d0f12;--ink-2:#3a3f4a;--ink-3:#7a8394;
    --line:#e8eaed;--line-2:#f1f3f5;
    --surface:#ffffff;--page:#f4f5f8;
    --accent:#6366f1;--accent-lt:#eef2ff;--accent-dk:#4338ca;
    --green:#16a34a;--green-lt:#dcfce7;--green-dk:#14532d;
    --red:#dc2626;--red-lt:#fee2e2;
    --amber:#d97706;--amber-lt:#fef3c7;
    --blue:#0284c7;--blue-lt:#e0f2fe;
    --sidebar-w:240px;--r:10px;--r-lg:14px;--r-xl:18px;
    --shadow:0 1px 3px rgba(0,0,0,.06),0 1px 2px rgba(0,0,0,.04);
    --shadow-md:0 4px 16px rgba(0,0,0,.09),0 2px 4px rgba(0,0,0,.05);
    --shadow-lg:0 10px 40px rgba(0,0,0,.12);
}
body{font-family:'DM Sans',sans-serif;background:var(--page);color:var(--ink);font-size:14px;line-height:1.55;}
.layout{display:flex;min-height:100vh;}

/* ── SIDEBAR ── */
.sidebar{width:var(--sidebar-w);flex-shrink:0;background:var(--ink);position:fixed;top:0;left:0;height:100vh;display:flex;flex-direction:column;z-index:50;overflow:hidden;transition:transform .25s ease;}
.sidebar-brand{padding:28px 20px 24px;border-bottom:1px solid rgba(255,255,255,.07);}
.brand-mark{display:flex;align-items:center;gap:10px;}
.brand-icon{width:34px;height:34px;background:var(--accent);border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.brand-icon svg{width:18px;height:18px;color:#fff;}
.brand-name{font-size:15px;font-weight:600;color:#fff;letter-spacing:-.2px;}
.brand-tagline{font-size:11px;color:rgba(255,255,255,.35);margin-top:1px;}
.sidebar-nav{padding:16px 12px;flex:1;overflow-y:auto;}
.nav-section-label{font-size:10px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:rgba(255,255,255,.25);padding:0 8px;margin:8px 0 6px;}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:7px;color:rgba(255,255,255,.5);text-decoration:none;font-size:13.5px;font-weight:400;transition:background .15s,color .15s;margin-bottom:2px;}
.nav-item svg{width:16px;height:16px;flex-shrink:0;}
.nav-item:hover{background:rgba(255,255,255,.06);color:rgba(255,255,255,.85);}
.nav-item.active{background:rgba(99,102,241,.2);color:#a5b4fc;font-weight:500;}
.sidebar-footer{padding:16px 12px;border-top:1px solid rgba(255,255,255,.06);}
.user-row{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:7px;}
.user-avatar{width:30px;height:30px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;color:#fff;flex-shrink:0;}
.user-name{font-size:12.5px;color:rgba(255,255,255,.7);font-weight:500;}

/* ── HAMBURGER ── */
.hamburger{display:none;position:fixed;top:16px;left:16px;z-index:100;background:var(--ink);border:none;color:#fff;width:40px;height:40px;border-radius:8px;cursor:pointer;align-items:center;justify-content:center;}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:40;}

/* ── MAIN ── */
.main{flex:1;margin-left:var(--sidebar-w);padding:32px 36px;display:flex;flex-direction:column;gap:24px;min-width:0;}

/* ── TOPBAR ── */
.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;}
.page-title{font-size:22px;font-weight:600;letter-spacing:-.4px;}
.page-sub{font-size:13px;color:var(--ink-3);margin-top:2px;}
.topbar-actions{display:flex;gap:10px;align-items:center;flex-shrink:0;}
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border-radius:var(--r);font-size:13px;font-weight:500;cursor:pointer;border:none;transition:all .15s;text-decoration:none;white-space:nowrap;}
.btn svg{width:14px;height:14px;flex-shrink:0;}
.btn-primary{background:var(--accent);color:#fff;}
.btn-primary:hover{background:var(--accent-dk);}
.btn-ghost{background:var(--surface);color:var(--ink-2);border:1px solid var(--line);}
.btn-ghost:hover{background:var(--line-2);}
.btn-danger{background:var(--red-lt);color:var(--red);border:1px solid #fecaca;}
.btn-danger:hover{background:#fecaca;}
.btn-sm{padding:5px 10px;font-size:12px;}

/* ── SUMMARY TRUST PANEL ── */
.summary-panel{background:var(--surface);border-radius:var(--r-xl);border:1px solid var(--line);box-shadow:var(--shadow-md);overflow:hidden;}
.summary-top{display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:0;}
.summary-block{padding:22px 24px;position:relative;}
.summary-block+.summary-block{border-left:1px solid var(--line);}
.summary-block.net{background:linear-gradient(135deg,#f8f9ff 0%,#eef2ff 100%);}
.s-label{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.7px;color:var(--ink-3);margin-bottom:6px;display:flex;align-items:center;gap:5px;}
.s-label .dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;}
.s-label .dot.green{background:var(--green);}
.s-label .dot.red{background:var(--red);}
.s-label .dot.blue{background:var(--accent);}
.s-amount{font-family:'DM Mono',monospace;font-size:24px;font-weight:600;letter-spacing:-1px;font-variant-numeric:tabular-nums;line-height:1;}
.s-amount.income{color:var(--green);}
.s-amount.expense{color:var(--red);}
.s-amount.net-pos{color:var(--green-dk);}
.s-amount.net-neg{color:var(--red);}
.s-meta{font-size:12px;color:var(--ink-3);margin-top:5px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;}
.s-meta .pill{display:inline-flex;align-items:center;gap:3px;background:var(--line-2);padding:2px 7px;border-radius:20px;font-size:11px;color:var(--ink-2);font-weight:500;}
.s-meta .pill.green{background:var(--green-lt);color:var(--green-dk);}
.s-meta .pill.red{background:var(--red-lt);color:var(--red);}
.s-sign{font-size:14px;font-weight:600;margin-right:1px;}

/* Sparkline */
.sparkline-wrap{display:flex;align-items:center;padding:22px 24px;border-left:1px solid var(--line);gap:12px;min-width:200px;}
.sparkline-label{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--ink-3);margin-bottom:6px;}
.sparkline-canvas{width:130px;height:44px;flex-shrink:0;}
.spark-days{display:flex;justify-content:space-between;font-size:9px;color:var(--ink-3);margin-top:3px;width:130px;}

/* Pagination note */
.pagination-note{display:flex;align-items:center;gap:8px;padding:10px 24px;background:#fffbeb;border-top:1px solid #fde68a;font-size:12.5px;color:#92400e;}
.pagination-note svg{width:14px;height:14px;flex-shrink:0;}
.pagination-note a{color:var(--accent);font-weight:500;text-decoration:none;}
.pagination-note a:hover{text-decoration:underline;}

/* Reconcile bar */
.reconcile-bar{display:flex;gap:4px;height:5px;border-radius:4px;overflow:hidden;margin-top:8px;}
.reconcile-seg{height:100%;border-radius:2px;transition:width .4s ease;}

/* ── FILTER BAR ── */
.filter-bar{background:var(--surface);border-radius:var(--r-lg);padding:16px 20px;border:1px solid var(--line);box-shadow:var(--shadow);}
.filter-form{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;}
.filter-group{display:flex;flex-direction:column;gap:4px;min-width:0;}
.filter-group label{font-size:11px;font-weight:600;color:var(--ink-3);text-transform:uppercase;letter-spacing:.5px;}
.filter-input{height:36px;padding:0 10px;border-radius:8px;border:1px solid var(--line);background:var(--page);color:var(--ink);font-size:13px;font-family:inherit;outline:none;transition:border-color .15s;}
.filter-input:focus{border-color:var(--accent);background:#fff;}
.search-wrap{position:relative;flex:1;min-width:180px;}
.search-wrap svg{position:absolute;left:10px;top:50%;transform:translateY(-50%);width:14px;height:14px;color:var(--ink-3);pointer-events:none;}
.search-input{padding-left:32px;width:100%;}
.type-chips{display:flex;gap:6px;}
.type-chip{padding:6px 12px;border-radius:20px;font-size:12px;font-weight:500;cursor:pointer;border:1px solid var(--line);background:var(--surface);color:var(--ink-2);transition:all .15s;text-decoration:none;}
.type-chip:hover{background:var(--line-2);}
.type-chip.active-income{background:var(--green-lt);color:var(--green-dk);border-color:var(--green);}
.type-chip.active-expense{background:var(--red-lt);color:var(--red);border-color:var(--red);}
.type-chip.active-all{background:var(--accent-lt);color:var(--accent);border-color:var(--accent);}
.active-filters{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px;}
.filter-tag{display:inline-flex;align-items:center;gap:5px;background:var(--accent-lt);color:var(--accent);font-size:11.5px;font-weight:500;padding:3px 8px 3px 10px;border-radius:20px;}
.filter-tag a{color:inherit;text-decoration:none;display:flex;align-items:center;margin-left:2px;}

/* ── TRANSACTION CARDS ── */
.tx-list-card{background:var(--surface);border-radius:var(--r-xl);border:1px solid var(--line);box-shadow:var(--shadow-md);overflow:hidden;}
.tx-list-header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--line);}
.tx-list-title{font-size:14px;font-weight:600;}
.tx-list-meta{font-size:12px;color:var(--ink-3);}

.tx-card{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:14px;padding:14px 20px;border-bottom:1px solid var(--line-2);transition:background .12s;position:relative;}
.tx-card:last-child{border-bottom:none;}
.tx-card:hover{background:var(--page);}
.tx-card:hover .tx-actions{opacity:1;}

/* Left border stripe */
.tx-card::before{content:'';position:absolute;left:0;top:8px;bottom:8px;width:3px;border-radius:0 3px 3px 0;opacity:0;transition:opacity .15s;}
.tx-card.income-row::before{background:var(--green);opacity:1;}
.tx-card.expense-row::before{background:var(--red);opacity:1;}

.tx-icon-wrap{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;transition:transform .2s;}
.tx-card:hover .tx-icon-wrap{transform:scale(1.08);}
.tx-icon-wrap.income-bg{background:var(--green-lt);}
.tx-icon-wrap.expense-bg{background:var(--red-lt);}
.tx-icon-wrap.other-bg{background:var(--amber-lt);}

.tx-center{min-width:0;}
.tx-top-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.tx-cat-name{font-weight:600;font-size:14px;color:var(--ink);}
.tx-type-pill{display:inline-flex;align-items:center;padding:2px 8px;border-radius:20px;font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.3px;}
.tx-type-pill.income{background:var(--green-lt);color:var(--green-dk);}
.tx-type-pill.expense{background:var(--red-lt);color:var(--red);}
.tx-type-pill.other{background:var(--amber-lt);color:var(--amber);}
.tx-desc{font-size:12px;color:var(--ink-3);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:380px;}
.tx-date-pill{font-size:11.5px;color:var(--ink-3);}

.tx-right{display:flex;flex-direction:column;align-items:flex-end;gap:6px;}
.tx-amount{font-family:'DM Mono',monospace;font-size:16px;font-weight:600;font-variant-numeric:tabular-nums;white-space:nowrap;}
.tx-amount.income{color:var(--green);}
.tx-amount.expense{color:var(--red);}
.tx-actions{display:flex;gap:5px;opacity:0;transition:opacity .15s;}
.icon-btn{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:6px;border:none;cursor:pointer;transition:background .15s;}
.icon-btn svg{width:13px;height:13px;}
.icon-btn.edit{background:var(--accent-lt);color:var(--accent);}
.icon-btn.edit:hover{background:#c7d2fe;}
.icon-btn.del{background:var(--red-lt);color:var(--red);}
.icon-btn.del:hover{background:#fecaca;}

/* ── MINI CHARTS ── */
.charts-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.chart-card{background:var(--surface);border-radius:var(--r-lg);border:1px solid var(--line);box-shadow:var(--shadow);padding:18px 20px;}
.chart-title{font-size:13px;font-weight:600;margin-bottom:14px;color:var(--ink);}
.donut-wrap{display:flex;align-items:center;gap:16px;}
.donut-canvas{width:90px;height:90px;flex-shrink:0;}
.donut-legend{display:flex;flex-direction:column;gap:6px;flex:1;}
.legend-item{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--ink-2);}
.legend-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
.legend-pct{font-weight:600;color:var(--ink);margin-left:auto;font-family:'DM Mono',monospace;}
.bar-list{display:flex;flex-direction:column;gap:10px;}
.bar-item{display:flex;flex-direction:column;gap:4px;}
.bar-item-top{display:flex;justify-content:space-between;font-size:12px;color:var(--ink-2);}
.bar-item-top .bar-val{font-family:'DM Mono',monospace;font-weight:500;color:var(--ink);}
.bar-track{height:6px;background:var(--line-2);border-radius:4px;overflow:hidden;}
.bar-fill{height:100%;border-radius:4px;}

/* ── EMPTY STATE ── */
.empty{text-align:center;padding:64px 20px;}
.empty-icon{font-size:44px;margin-bottom:14px;}
.empty-title{font-size:16px;font-weight:600;margin-bottom:6px;}
.empty-sub{font-size:13px;color:var(--ink-3);}

/* ── PAGINATION ── */
.pagination{display:flex;align-items:center;justify-content:space-between;padding:14px 20px;border-top:1px solid var(--line);flex-wrap:wrap;gap:8px;}
.pagination-info{font-size:12.5px;color:var(--ink-3);}
.pagination-btns{display:flex;gap:4px;}
.page-btn{display:inline-flex;align-items:center;justify-content:center;min-width:32px;height:32px;padding:0 8px;border-radius:7px;font-size:13px;font-weight:500;text-decoration:none;color:var(--ink-2);border:1px solid var(--line);background:var(--surface);transition:all .15s;}
.page-btn:hover{background:var(--page);color:var(--ink);}
.page-btn.active{background:var(--accent);color:#fff;border-color:var(--accent);}
.page-btn.disabled{opacity:.4;pointer-events:none;}

/* ── FAB ── */
.fab{position:fixed;bottom:28px;right:28px;z-index:90;width:52px;height:52px;border-radius:50%;background:var(--accent);color:#fff;border:none;cursor:pointer;box-shadow:0 4px 20px rgba(99,102,241,.45);display:flex;align-items:center;justify-content:center;transition:transform .2s,box-shadow .2s;font-size:26px;line-height:1;}
.fab:hover{transform:scale(1.1);box-shadow:0 6px 28px rgba(99,102,241,.55);}
.fab svg{width:22px;height:22px;}

/* ── MODAL ── */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:200;align-items:center;justify-content:center;padding:16px;}
.modal-overlay.open{display:flex;}
.modal{background:var(--surface);border-radius:var(--r-xl);width:100%;max-width:480px;box-shadow:var(--shadow-lg);overflow:hidden;animation:slideUp .2s ease;}
@keyframes slideUp{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
.modal-header{display:flex;align-items:center;justify-content:space-between;padding:20px 24px;border-bottom:1px solid var(--line);}
.modal-title{font-size:16px;font-weight:600;}
.modal-close{background:none;border:none;cursor:pointer;color:var(--ink-3);display:flex;padding:4px;border-radius:6px;}
.modal-close:hover{background:var(--line-2);color:var(--ink);}
.modal-close svg{width:18px;height:18px;}
.modal-body{padding:24px;}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.form-group{display:flex;flex-direction:column;gap:5px;margin-bottom:14px;}
.form-group:last-child{margin-bottom:0;}
.form-label{font-size:11.5px;font-weight:600;color:var(--ink-2);text-transform:uppercase;letter-spacing:.4px;}
.form-control{height:40px;padding:0 12px;border-radius:9px;border:1px solid var(--line);font-size:13.5px;font-family:inherit;color:var(--ink);background:var(--page);outline:none;transition:border-color .15s,box-shadow .15s;}
.form-control:focus{border-color:var(--accent);background:#fff;box-shadow:0 0 0 3px rgba(99,102,241,.1);}
textarea.form-control{height:auto;padding:10px 12px;resize:vertical;}
.modal-footer{display:flex;gap:10px;justify-content:flex-end;padding:16px 24px;border-top:1px solid var(--line);}
.del-confirm{padding:28px 24px;text-align:center;}
.del-confirm-icon{font-size:40px;margin-bottom:12px;}
.del-confirm-title{font-size:16px;font-weight:600;margin-bottom:6px;}
.del-confirm-sub{font-size:13px;color:var(--ink-3);margin-bottom:22px;}

/* ── TOAST ── */
.toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(10px);background:var(--ink);color:#fff;padding:12px 20px;border-radius:var(--r);font-size:13px;font-weight:500;box-shadow:var(--shadow-md);z-index:500;opacity:0;transition:all .25s;pointer-events:none;white-space:nowrap;}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
.toast.success{background:#14532d;}
.toast.error{background:#9f1239;}

/* ── RESPONSIVE ── */
@media(max-width:1024px){
    .charts-row{grid-template-columns:1fr;}
    .summary-top{grid-template-columns:1fr 1fr;}
    .sparkline-wrap{border-left:none;border-top:1px solid var(--line);}
}
@media(max-width:900px){
    .hamburger{display:flex;}
    .sidebar{transform:translateX(-100%);}
    .sidebar.open{transform:translateX(0);}
    .sidebar-overlay.open{display:block;}
    .main{margin-left:0;padding:20px 16px;padding-top:68px;}
    .summary-top{grid-template-columns:1fr 1fr;}
}
@media(max-width:640px){
    .summary-top{grid-template-columns:1fr;}
    .summary-block+.summary-block{border-left:none;border-top:1px solid var(--line);}
    .sparkline-wrap{border-left:none;border-top:1px solid var(--line);}
    .form-row{grid-template-columns:1fr;}
    .tx-actions{opacity:1;}
    .topbar-actions .btn span{display:none;}
    .fab{bottom:20px;right:20px;}
}
</style>
</head>
<body>

<button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
</button>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>

<div class="layout">
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-mark">
      <div class="brand-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/><path d="M12 6v6l4 2"/></svg>
      </div>
      <div>
        <div class="brand-name">Finance</div>
        <div class="brand-tagline">Personal tracker</div>
      </div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Menu</div>
    <a href="dashboard.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard</a>
    <a href="transactions.php" class="nav-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>Transactions</a>
    <a href="budget.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>Budget</a>
    <a href="savings_goals.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 9c0 4-4 4-4 4H7v5H3V9a6 6 0 0 1 12 0h2z"/><circle cx="21" cy="14" r="3"/></svg>Savings Goals</a>
    <a href="recurring_transaction.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>Recurring</a>
    <a href="debts.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>Debts &amp; Loans</a>
    <div class="nav-section-label" style="margin-top:16px;">Account</div>
    <a href="settings.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>Settings</a>
    <a href="logout.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>Logout</a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-row">
      <div class="user-avatar"><?php echo strtoupper(substr($user_name, 0, 1)); ?></div>
      <div>
        <div class="user-name"><?php echo htmlspecialchars($user_name); ?></div>
        <div style="font-size:11px;color:rgba(255,255,255,.3);"><?php echo htmlspecialchars($_SESSION['role'] ?? 'user'); ?></div>
      </div>
    </div>
  </div>
</aside>

<main class="main">

  <!-- TOPBAR -->
  <div class="topbar">
    <div>
      <div class="page-title">Hi <?php echo htmlspecialchars(explode(' ', $user_name)[0]); ?> 👋</div>
      <div class="page-sub">Here's your complete transaction history</div>
    </div>
    <div class="topbar-actions">
      <a href="<?php echo qs(['export'=>'csv']); ?>" class="btn btn-ghost">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
        <span>Export CSV</span>
      </a>
      <button class="btn btn-primary" onclick="openAddModal()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
        <span>Add Transaction</span>
      </button>
    </div>
  </div>

  <!-- TRUST SUMMARY PANEL -->
  <div class="summary-panel">
    <div class="summary-top">

      <!-- INCOME -->
      <div class="summary-block">
        <div class="s-label"><span class="dot green"></span>Total Income</div>
        <div class="s-amount income" id="animIncome">KES 0</div>
        <div class="s-meta">
          <span class="pill green"><?php echo number_format($income_count); ?> transaction<?php echo $income_count!=1?'s':''; ?></span>
          <?php if ($has_filter && $filtered_income !== $total_income): ?>
            <span style="color:var(--ink-3);">·</span>
            <span>KES <?php echo number_format($filtered_income); ?> in view</span>
          <?php endif; ?>
        </div>
        <div class="reconcile-bar" style="margin-top:10px;">
          <div class="reconcile-seg" style="background:var(--green);width:<?php echo $total_income+$total_expense>0 ? round($total_income/($total_income+$total_expense)*100) : 50; ?>%"></div>
          <div class="reconcile-seg" style="background:var(--line-2);flex:1;"></div>
        </div>
      </div>

      <!-- EXPENSES -->
      <div class="summary-block">
        <div class="s-label"><span class="dot red"></span>Total Expenses</div>
        <div class="s-amount expense" id="animExpense">KES 0</div>
        <div class="s-meta">
          <span class="pill red"><?php echo number_format($expense_count); ?> transaction<?php echo $expense_count!=1?'s':''; ?></span>
          <?php if ($has_filter && $filtered_expense !== $total_expense): ?>
            <span style="color:var(--ink-3);">·</span>
            <span>KES <?php echo number_format($filtered_expense); ?> in view</span>
          <?php endif; ?>
        </div>
        <div class="reconcile-bar" style="margin-top:10px;">
          <div class="reconcile-seg" style="background:var(--red);width:<?php echo $total_income+$total_expense>0 ? round($total_expense/($total_income+$total_expense)*100) : 50; ?>%"></div>
          <div class="reconcile-seg" style="background:var(--line-2);flex:1;"></div>
        </div>
      </div>

      <!-- NET BALANCE -->
      <div class="summary-block net">
        <div class="s-label"><span class="dot blue"></span>Net Balance</div>
        <div class="s-amount <?php echo $net >= 0 ? 'net-pos' : 'net-neg'; ?>" id="animNet">KES 0</div>
        <div class="s-meta">
          <?php if ($net > 0): ?>
            <span class="pill green">↑ Positive</span>
            <span style="color:var(--ink-3);">Saving <?php echo $total_income > 0 ? round($net/$total_income*100) : 0; ?>% of income</span>
          <?php elseif ($net < 0): ?>
            <span class="pill red">↓ Deficit</span>
            <span style="color:var(--ink-3);">Overspent by KES <?php echo number_format(abs($net)); ?></span>
          <?php else: ?>
            <span class="pill">Breakeven</span>
          <?php endif; ?>
        </div>
        <div class="reconcile-bar" style="margin-top:10px;">
          <?php $netPct = $total_income > 0 ? min(100, max(0, round(abs($net)/$total_income*100))) : 0; ?>
          <div class="reconcile-seg" style="background:<?php echo $net>=0?'var(--green)':'var(--red)'; ?>;width:<?php echo $netPct; ?>%"></div>
          <div class="reconcile-seg" style="background:var(--line-2);flex:1;"></div>
        </div>
      </div>

      <!-- SPARKLINE -->
      <div class="sparkline-wrap">
        <div>
          <div class="sparkline-label">7-Day Net</div>
          <canvas class="sparkline-canvas" id="sparkCanvas"></canvas>
          <div class="spark-days" id="sparkDays"></div>
        </div>
      </div>

    </div>

    <?php
    $hidden = max(0, $total_rows - min($page_num * $per_page, $total_rows));
    $before = ($page_num - 1) * $per_page;
    if ($total_pages > 1):
    ?>
    <div class="pagination-note">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
      Showing page <?php echo $page_num; ?> of <?php echo $total_pages; ?> —
      <strong><?php echo $total_rows; ?> total records</strong>.
      The summary above reflects <strong>all <?php echo number_format($total_count); ?> transactions</strong>, not just this page.
      <?php if ($hidden > 0): ?>
        <a href="<?php echo qs(['page'=>$total_pages]); ?>">+<?php echo $hidden; ?> more →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- FILTER BAR -->
  <div class="filter-bar">
    <form method="GET" class="filter-form" id="filterForm">
      <!-- Type chips -->
      <div class="filter-group" style="flex-shrink:0;">
        <label>Type</label>
        <div class="type-chips">
          <a href="<?php echo qs(['type'=>'','page'=>1]); ?>" class="type-chip <?php echo !$type?'active-all':''; ?>">All</a>
          <a href="<?php echo qs(['type'=>'income','page'=>1]); ?>" class="type-chip <?php echo $type==='income'?'active-income':''; ?>">↑ Income</a>
          <a href="<?php echo qs(['type'=>'expense','page'=>1]); ?>" class="type-chip <?php echo $type==='expense'?'active-expense':''; ?>">↓ Expense</a>
        </div>
      </div>
      <!-- Search -->
      <div class="filter-group search-wrap" style="flex:1;">
        <label>Search</label>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input type="text" name="search" class="filter-input search-input" placeholder="Category or description…" value="<?php echo htmlspecialchars($search); ?>">
      </div>
      <!-- Category -->
      <div class="filter-group">
        <label>Category</label>
        <select name="category" class="filter-input" onchange="this.form.submit()">
          <option value="">All Categories</option>
          <?php while($cat = $cats->fetch_assoc()): if(empty($cat['category'])) continue; ?>
            <option value="<?php echo htmlspecialchars($cat['category']); ?>" <?php if($category===$cat['category']) echo 'selected'; ?>><?php echo htmlspecialchars($cat['category']); ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <!-- Date range -->
      <div class="filter-group">
        <label>From</label>
        <input type="date" name="date_from" class="filter-input" value="<?php echo htmlspecialchars($date_from); ?>" onchange="this.form.submit()">
      </div>
      <div class="filter-group">
        <label>To</label>
        <input type="date" name="date_to" class="filter-input" value="<?php echo htmlspecialchars($date_to); ?>" onchange="this.form.submit()">
      </div>
      <div class="filter-group">
        <label>&nbsp;</label>
        <button type="submit" class="btn btn-primary" style="height:36px;">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          Search
        </button>
      </div>
      <?php if ($search || $type || $category || $date_from || $date_to): ?>
      <div class="filter-group">
        <label>&nbsp;</label>
        <a href="transactions.php" class="btn btn-ghost" style="height:36px;">✕ Clear</a>
      </div>
      <?php endif; ?>
      <input type="hidden" name="sort" value="<?php echo $sort; ?>">
      <input type="hidden" name="type" value="<?php echo htmlspecialchars($type); ?>">
    </form>
    <?php $af=[];
    if($search) $af[]='Search: "'.htmlspecialchars($search).'"';
    if($category) $af[]='Category: '.htmlspecialchars($category);
    if($date_from) $af[]='From: '.$date_from;
    if($date_to) $af[]='To: '.$date_to;
    if($af): ?>
    <div class="active-filters" style="margin-top:10px;">
      <?php foreach($af as $f): ?>
        <span class="filter-tag"><?php echo $f; ?> <a href="transactions.php">✕</a></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- MINI CHARTS -->
  <?php if (!empty($cat_data)): ?>
  <div class="charts-row">
    <!-- Expense breakdown donut -->
    <div class="chart-card">
      <div class="chart-title">Expense Breakdown by Category</div>
      <div class="donut-wrap">
        <canvas class="donut-canvas" id="donutCanvas"></canvas>
        <div class="donut-legend" id="donutLegend"></div>
      </div>
    </div>
    <!-- Income vs Expense bar -->
    <div class="chart-card">
      <div class="chart-title">Income vs Expenses</div>
      <?php
      $maxBar = max($total_income, $total_expense, 1);
      ?>
      <div class="bar-list">
        <div class="bar-item">
          <div class="bar-item-top">
            <span style="color:var(--green);font-weight:600;">↑ Income</span>
            <span class="bar-val" style="color:var(--green);">KES <?php echo number_format($total_income); ?></span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:<?php echo round($total_income/$maxBar*100); ?>%;background:var(--green);"></div></div>
        </div>
        <div class="bar-item">
          <div class="bar-item-top">
            <span style="color:var(--red);font-weight:600;">↓ Expenses</span>
            <span class="bar-val" style="color:var(--red);">KES <?php echo number_format($total_expense); ?></span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:<?php echo round($total_expense/$maxBar*100); ?>%;background:var(--red);"></div></div>
        </div>
        <?php foreach ($cat_data as $cd): $w = round($cd['total']/$maxBar*100); ?>
        <div class="bar-item">
          <div class="bar-item-top">
            <span style="color:var(--ink-2);"><?php echo htmlspecialchars($cd['category']); ?></span>
            <span class="bar-val">KES <?php echo number_format($cd['total']); ?></span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:<?php echo $w; ?>%;background:var(--accent);opacity:.7;"></div></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- TRANSACTION CARDS -->
  <div class="tx-list-card">
    <div class="tx-list-header">
      <div>
        <div class="tx-list-title">
          <?php echo number_format($total_rows); ?> Transaction<?php echo $total_rows!=1?'s':''; ?>
          <?php if($has_filter) echo ' <span style="font-weight:400;color:var(--ink-3);">matching filters</span>'; ?>
        </div>
        <div class="tx-list-meta">Page <?php echo $page_num; ?> of <?php echo $total_pages; ?> · <?php echo $per_page; ?> per page</div>
      </div>
      <a href="<?php echo qs(['sort'=>$sort==='asc'?'desc':'asc']); ?>" class="btn btn-ghost btn-sm">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 16V4m0 0L3 8m4-4 4 4M17 8v12m0 0 4-4m-4 4-4-4"/></svg>
        <?php echo $sort === 'desc' ? 'Oldest first' : 'Newest first'; ?>
      </a>
    </div>

    <?php
    $icons = ['Food'=>'🍔','Transport'=>'🚗','Utilities'=>'💡','Entertainment'=>'🎬','Shopping'=>'🛍️','Health'=>'💊','Salary'=>'💼','Business'=>'📊','Investments'=>'📈','Shares'=>'📉','Freelance'=>'💻','Family'=>'👨‍👩‍👧','Rental'=>'🏠','Gift'=>'🎁','Other'=>'📦','salary'=>'💼','rent'=>'🏠','car'=>'🚗','loan'=>'💳','stocks'=>'📈','laptop'=>'💻','Traveling'=>'✈️','Groceries'=>'🛒','Fuel & Charging'=>'⛽','Clothing & Accessories'=>'👗','Electronics & Tech'=>'📱','Eating Out'=>'🍽️','Personal Grooming'=>'✂️','Health & Pharmacy'=>'💊','Gifts & Celebrations'=>'🎉','Pet Supplies'=>'🐾','Household Supplies'=>'🧹','Commuting'=>'🚌','Vehicle Maintenance'=>'🔧','Home Decor'=>'🛋️','Maintenance & DIY'=>'🔨','Kitchenware'=>'🍳','Impulse Buys'=>'🛒','Other Income'=>'💰'];
    if ($transactions->num_rows > 0):
        while ($tx = $transactions->fetch_assoc()):
            $dd       = display_date($tx);
            $type_cls = strtolower($tx['type']) === 'income' ? 'income' : (strtolower($tx['type']) === 'expense' ? 'expense' : 'other');
            $sign     = $type_cls === 'income' ? '+' : ($type_cls === 'expense' ? '−' : '');
            $icon     = $icons[$tx['category']] ?? ($type_cls === 'income' ? '💵' : '💸');
            $icon_cls = $type_cls === 'income' ? 'income-bg' : ($type_cls === 'expense' ? 'expense-bg' : 'other-bg');
            $row_cls  = $type_cls === 'income' ? 'income-row' : ($type_cls === 'expense' ? 'expense-row' : '');
            $desc     = trim($tx['description'] ?? '');
            // Auto-capitalise, remove duplicate cat mentions
            $cat_display = ucwords(strtolower($tx['category']));
    ?>
    <div class="tx-card <?php echo $row_cls; ?>">
      <div class="tx-icon-wrap <?php echo $icon_cls; ?>"><?php echo $icon; ?></div>
      <div class="tx-center">
        <div class="tx-top-row">
          <span class="tx-cat-name"><?php echo htmlspecialchars($cat_display); ?></span>
          <span class="tx-type-pill <?php echo $type_cls; ?>"><?php echo htmlspecialchars(ucfirst($tx['type'])); ?></span>
        </div>
        <?php if ($desc): ?>
          <div class="tx-desc"><?php echo htmlspecialchars(ucfirst($desc)); ?></div>
        <?php endif; ?>
        <div class="tx-date-pill"><?php echo $dd; ?></div>
      </div>
      <div class="tx-right">
        <span class="tx-amount <?php echo $type_cls; ?>"><?php echo $sign; ?>KES <?php echo number_format($tx['amount']); ?></span>
        <div class="tx-actions">
          <button class="icon-btn edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($tx)); ?>)" title="Edit">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="icon-btn del" onclick="openDeleteModal(<?php echo $tx['transaction_id']; ?>, '<?php echo htmlspecialchars($cat_display); ?>')" title="Delete">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
          </button>
        </div>
      </div>
    </div>
    <?php endwhile; else: ?>
    <div class="empty">
      <div class="empty-icon">🔍</div>
      <div class="empty-title">No transactions found</div>
      <div class="empty-sub">Try adjusting your filters or add a new transaction.</div>
    </div>
    <?php endif; ?>

    <?php if ($total_pages > 1): ?>
    <div class="pagination">
      <div class="pagination-info">Showing <?php echo $offset+1; ?>–<?php echo min($offset+$per_page,$total_rows); ?> of <?php echo number_format($total_rows); ?></div>
      <div class="pagination-btns">
        <a href="<?php echo qs(['page'=>$page_num-1]); ?>" class="page-btn <?php echo $page_num<=1?'disabled':''; ?>">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </a>
        <?php
        $rs = max(1, $page_num-2); $re = min($total_pages, $page_num+2);
        if ($rs > 1) echo '<span class="page-btn disabled">…</span>';
        for ($i=$rs; $i<=$re; $i++):
        ?><a href="<?php echo qs(['page'=>$i]); ?>" class="page-btn <?php echo $i===$page_num?'active':''; ?>"><?php echo $i; ?></a><?php
        endfor;
        if ($re < $total_pages) echo '<span class="page-btn disabled">…</span>';
        ?>
        <a href="<?php echo qs(['page'=>$page_num+1]); ?>" class="page-btn <?php echo $page_num>=$total_pages?'disabled':''; ?>">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </a>
      </div>
    </div>
    <?php endif; ?>
  </div>

</main>
</div>

<!-- FAB -->
<button class="fab" onclick="openAddModal()" title="Add Transaction">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
</button>

<!-- ADD/EDIT MODAL -->
<div class="modal-overlay" id="txModal">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title" id="modalTitle">Add Transaction</div>
      <button class="modal-close" onclick="closeModal('txModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    </div>
    <div class="modal-body">
      <form id="txForm">
        <input type="hidden" id="txId" name="id" value="">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Type</label>
            <select name="type" id="txType" class="form-control" required onchange="updateCategories()">
              <option value="expense">Expense</option>
              <option value="income">Income</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Category</label>
            <select name="category" id="txCategory" class="form-control" required></select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Amount (KES)</label>
            <input type="number" name="amount" id="txAmount" class="form-control" min="1" step="any" placeholder="0.00" required>
          </div>
          <div class="form-group">
            <label class="form-label">Date</label>
            <input type="date" name="created_at" id="txDate" class="form-control" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Description (optional)</label>
          <textarea name="description" id="txDesc" class="form-control" rows="2" placeholder="What was this for?"></textarea>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('txModal')">Cancel</button>
      <button class="btn btn-primary" onclick="submitTx()">Save Transaction</button>
    </div>
  </div>
</div>

<!-- DELETE CONFIRM MODAL -->
<div class="modal-overlay" id="delModal">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">Confirm Delete</div>
      <button class="modal-close" onclick="closeModal('delModal')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    </div>
    <div class="del-confirm">
      <div class="del-confirm-icon">🗑️</div>
      <div class="del-confirm-title">Delete this transaction?</div>
      <div class="del-confirm-sub" id="delSub">This action cannot be undone.</div>
      <div style="display:flex;gap:10px;justify-content:center;">
        <button class="btn btn-ghost" onclick="closeModal('delModal')">Cancel</button>
        <a href="#" id="delConfirmBtn" class="btn btn-danger">Yes, Delete</a>
      </div>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
/* ── DATA FROM PHP ── */
const SPARK_DATA  = <?php echo json_encode($spark); ?>;
const DONUT_DATA  = <?php echo json_encode($cat_data); ?>;
const INCOME_VAL  = <?php echo $total_income; ?>;
const EXPENSE_VAL = <?php echo $total_expense; ?>;
const NET_VAL     = <?php echo $net; ?>;

const EXPENSE_CATS = ['Groceries','Household Supplies','Eating Out','Fuel & Charging','Vehicle Maintenance','Commuting','Utilities','Home Decor','Maintenance & DIY','Kitchenware','Health & Pharmacy','Personal Grooming','Clothing & Accessories','Electronics & Tech','Entertainment','Gifts & Celebrations','Pet Supplies','Impulse Buys','Other'];
const INCOME_CATS  = ['Salary','Business','Investments','Shares','Freelance','Family','Rental','Gift','Other Income'];

/* ── ANIMATED COUNTER ── */
function animateCount(el, target, prefix='KES ') {
    const dur = 900, steps = 50, inc = target / steps;
    let cur = 0, s = 0;
    const t = setInterval(() => {
        cur = Math.min(cur + inc, target);
        el.textContent = prefix + new Intl.NumberFormat().format(Math.round(cur));
        if (++s >= steps) { el.textContent = prefix + new Intl.NumberFormat().format(target); clearInterval(t); }
    }, dur / steps);
}
window.addEventListener('DOMContentLoaded', () => {
    animateCount(document.getElementById('animIncome'),  INCOME_VAL);
    animateCount(document.getElementById('animExpense'), EXPENSE_VAL);
    animateCount(document.getElementById('animNet'),     Math.abs(NET_VAL));
    drawSparkline();
    drawDonut();
});

/* ── SPARKLINE ── */
function drawSparkline() {
    const canvas = document.getElementById('sparkCanvas');
    if (!canvas || !SPARK_DATA.length) return;
    const ctx = canvas.getContext('2d');
    const W = 130, H = 44;
    canvas.width = W * 2; canvas.height = H * 2; canvas.style.width = W+'px'; canvas.style.height = H+'px';
    ctx.scale(2, 2);
    const vals = SPARK_DATA.map(d => d.net);
    const mn = Math.min(...vals), mx = Math.max(...vals);
    const range = mx - mn || 1;
    const pad = 6;
    const pts = vals.map((v, i) => ({
        x: pad + (i / (vals.length - 1)) * (W - pad*2),
        y: H - pad - ((v - mn) / range) * (H - pad*2)
    }));

    // Gradient fill
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, 'rgba(99,102,241,.25)');
    grad.addColorStop(1, 'rgba(99,102,241,0)');
    ctx.beginPath();
    ctx.moveTo(pts[0].x, H);
    pts.forEach(p => ctx.lineTo(p.x, p.y));
    ctx.lineTo(pts[pts.length-1].x, H);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.beginPath();
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.strokeStyle = '#6366f1';
    ctx.lineWidth = 1.5;
    ctx.lineJoin = 'round';
    ctx.stroke();

    // Dots
    pts.forEach((p, i) => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = vals[i] >= 0 ? '#16a34a' : '#dc2626';
        ctx.fill();
    });

    // Day labels
    const daysEl = document.getElementById('sparkDays');
    daysEl.innerHTML = SPARK_DATA.map(d => `<span>${d.date}</span>`).join('');
}

/* ── DONUT CHART ── */
function drawDonut() {
    const canvas = document.getElementById('donutCanvas');
    if (!canvas || !DONUT_DATA.length) return;
    const ctx = canvas.getContext('2d');
    const S = 90;
    canvas.width = S*2; canvas.height = S*2; canvas.style.width=S+'px'; canvas.style.height=S+'px';
    ctx.scale(2, 2);
    const colors = ['#dc2626','#d97706','#16a34a','#6366f1','#0284c7','#9333ea'];
    const total = DONUT_DATA.reduce((s, d) => s + parseFloat(d.total), 0);
    let angle = -Math.PI/2;
    const cx = S/2, cy = S/2, r = S/2 - 4, ri = r * 0.58;

    DONUT_DATA.forEach((d, i) => {
        const slice = (parseFloat(d.total) / total) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, r, angle, angle + slice);
        ctx.closePath();
        ctx.fillStyle = colors[i % colors.length];
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx, cy, ri, 0, Math.PI*2);
        ctx.fillStyle = '#fff';
        ctx.fill();
        angle += slice;
    });

    const legend = document.getElementById('donutLegend');
    const colors2 = ['#dc2626','#d97706','#16a34a','#6366f1','#0284c7','#9333ea'];
    legend.innerHTML = DONUT_DATA.map((d, i) => `
        <div class="legend-item">
            <div class="legend-dot" style="background:${colors2[i%colors2.length]}"></div>
            <span>${d.category}</span>
            <span class="legend-pct">${Math.round(d.total/total*100)}%</span>
        </div>`).join('');
}

/* ── CATEGORIES ── */
function updateCategories() {
    const type = document.getElementById('txType').value;
    const sel  = document.getElementById('txCategory');
    const cur  = sel.value;
    const cats = type === 'income' ? INCOME_CATS : EXPENSE_CATS;
    sel.innerHTML = cats.map(c => `<option value="${c}"${c===cur?' selected':''}>${c}</option>`).join('');
}

/* ── MODAL ── */
function openAddModal() {
    document.getElementById('modalTitle').textContent = 'Add Transaction';
    document.getElementById('txId').value = '';
    document.getElementById('txType').value = 'expense';
    updateCategories();
    document.getElementById('txAmount').value = '';
    document.getElementById('txDate').value = new Date().toISOString().split('T')[0];
    document.getElementById('txDesc').value = '';
    document.getElementById('txModal').classList.add('open');
}
function openEditModal(tx) {
    document.getElementById('modalTitle').textContent = 'Edit Transaction';
    document.getElementById('txId').value = tx.transaction_id;
    document.getElementById('txType').value = tx.type.toLowerCase();
    updateCategories();
    document.getElementById('txCategory').value = tx.category;
    document.getElementById('txAmount').value = tx.amount;
    let d = tx.date && tx.date !== '0000-00-00' ? tx.date : tx.created_at.split(' ')[0];
    document.getElementById('txDate').value = d;
    document.getElementById('txDesc').value = tx.description || '';
    document.getElementById('txModal').classList.add('open');
}
function openDeleteModal(id, name) {
    document.getElementById('delSub').textContent = `Deleting "${name}" — this cannot be undone.`;
    document.getElementById('delConfirmBtn').href = `delete_transaction.php?id=${id}`;
    document.getElementById('delModal').classList.add('open');
}
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

async function submitTx() {
    const form = document.getElementById('txForm');
    const id   = document.getElementById('txId').value;
    const data = new FormData(form);
    const url  = id ? 'edit_transaction.php' : 'add_transaction.php';
    try {
        const res  = await fetch(url, {method:'POST', body:data});
        const json = await res.json();
        if (json.csrf_token) { const el = form.querySelector('input[name="csrf_token"]'); if(el) el.value = json.csrf_token; }
        if (json.success) { closeModal('txModal'); showToast(id ? 'Transaction updated!' : 'Transaction added!', 'success'); setTimeout(() => location.reload(), 800); }
        else showToast(json.message || 'Something went wrong.', 'error');
    } catch(e) { showToast('Network error. Please try again.', 'error'); }
}

function showToast(msg, type='success') {
    const t = document.getElementById('toast');
    t.textContent = msg; t.className = 'toast show ' + type;
    setTimeout(() => t.classList.remove('show'), 3200);
}
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('overlay').classList.toggle('open');
}
document.querySelectorAll('.modal-overlay').forEach(el => el.addEventListener('click', function(e){ if(e.target===this) this.classList.remove('open'); }));
document.querySelector('.search-input')?.addEventListener('keydown', e => { if(e.key==='Enter') e.target.closest('form').submit(); });

const urlMsg = new URLSearchParams(location.search).get('msg');
if (urlMsg === 'success') showToast('Transaction deleted.', 'success');

updateCategories();
</script>
</body>
</html>