<?php
// ============================================================
// CRITICAL FIX #2: No more hardcoded credentials
// Loads from .env file — root/empty password removed
// ============================================================

// Load .env file
$env_path = __DIR__ . '/.env';
if (file_exists($env_path)) {
    $lines = file($env_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (!str_contains($line, '=')) continue;
        [$key, $val] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($val);
    }
}

$host = $_ENV['DB_HOST'] ?? 'localhost';
$db   = $_ENV['DB_NAME'] ?? 'finance_db';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    // NEVER expose raw DB errors to users in production
    error_log("DB connection failed: " . $conn->connect_error);
    die("Service temporarily unavailable. Please try again later.");
}

// Force UTF-8 charset
$conn->set_charset('utf8mb4');
?>